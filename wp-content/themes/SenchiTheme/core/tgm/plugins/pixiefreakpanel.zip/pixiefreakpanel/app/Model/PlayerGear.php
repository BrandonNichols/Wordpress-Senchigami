<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class PlayerGear extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'player_gear';
}
<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class About extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'about';
}
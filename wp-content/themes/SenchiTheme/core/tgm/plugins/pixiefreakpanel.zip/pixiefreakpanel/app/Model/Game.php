<?php

namespace PixieFreakPanel\Model;

use FusionFramework\Database\ORM;

class Game extends ORM
{
    /**
     * @var string $table
     */
    protected $table = 'game';
}